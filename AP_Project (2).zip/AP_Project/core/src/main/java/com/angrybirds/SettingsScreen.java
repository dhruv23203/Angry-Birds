package com.angrybirds;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.math.Vector3;

public class SettingsScreen implements Screen {
    private final MyAngryBirdGame game;
    private OrthographicCamera camera;
    private Viewport viewport;
    private BitmapFont font;
    private GlyphLayout layout;

    // Textures for buttons and background
    private Texture musicToggleButton;
    private Texture backButton;
    private Texture backgroundTexture;
    private boolean isMusicPlaying;

    private Vector3 touchPoint;

    // Screen dimensions
    private static final float WORLD_WIDTH = 1390f;
    private static final float WORLD_HEIGHT = 720f;
    private static final float CENTER_X = WORLD_WIDTH/2;

    // Button dimensions
    private static final float MUSIC_BUTTON_WIDTH = 600f;
    private static final float MUSIC_BUTTON_HEIGHT = 600f;
    private static final float BACK_BUTTON_SIZE = 80f;

    // Button positions
    private final float musicButtonX;
    private final float musicButtonY;

    public SettingsScreen(MyAngryBirdGame game) {
        this.game = game;
        this.isMusicPlaying = game.isMusicPlaying();

        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        camera.position.set(WORLD_WIDTH/2, WORLD_HEIGHT/2, 0);

        // Initialize font
        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("Smooch-Regular.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter parameter = new FreeTypeFontGenerator.FreeTypeFontParameter();
        parameter.size = 65;
        parameter.color = Color.WHITE;
        parameter.borderWidth = 2;
        parameter.borderColor = Color.BLACK;
        font = generator.generateFont(parameter);
        generator.dispose();

        layout = new GlyphLayout();

        // Load textures
        musicToggleButton = new Texture(Gdx.files.internal("music_toggle.png"));
        backButton = new Texture(Gdx.files.internal("back.png"));
        backgroundTexture = new Texture(Gdx.files.internal("background2.png"));

        touchPoint = new Vector3();

        // Calculate button positions
        musicButtonX = CENTER_X - MUSIC_BUTTON_WIDTH/2;
        musicButtonY = WORLD_HEIGHT/2 - MUSIC_BUTTON_HEIGHT/2;
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.1f, 0.1f, 0.1f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        // Handle input with specific coordinate ranges
        if (Gdx.input.justTouched()) {
            touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0);
            viewport.unproject(touchPoint);

            // Music toggle button input area
            if (touchPoint.x >= musicButtonX + 80f && touchPoint.x <= musicButtonX + MUSIC_BUTTON_WIDTH - 80f) {
                if (touchPoint.y >= musicButtonY + 180f && touchPoint.y <= musicButtonY + MUSIC_BUTTON_HEIGHT - 190f) {
                    toggleMusic();
                }
            }

            // Back button input area
            if (touchPoint.x >= 13f && touchPoint.x <= 13f + BACK_BUTTON_SIZE - 20f) {
                if (touchPoint.y >= WORLD_HEIGHT - BACK_BUTTON_SIZE - 20f &&
                    touchPoint.y <= WORLD_HEIGHT - 40f) {
                    dispose();
                    game.setScreen(new MainMenuScreen(game));
                    return;
                }
            }
        }

        game.batch.begin();

        // Draw background
        game.batch.draw(backgroundTexture, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);

        // Draw title
        layout.setText(font, "Settings");
        font.draw(game.batch, "Settings",
            WORLD_WIDTH/2 - layout.width/2,
            WORLD_HEIGHT - 50);

        // Draw music toggle button
        game.batch.draw(musicToggleButton,
            musicButtonX, musicButtonY,
            MUSIC_BUTTON_WIDTH, MUSIC_BUTTON_HEIGHT);

        // Draw music status text
        String musicStatus = isMusicPlaying ? "Music: ON" : "Music: OFF";
        layout.setText(font, musicStatus);
        float textX = musicButtonX + (MUSIC_BUTTON_WIDTH - layout.width) / 2;
        float textY = musicButtonY + (MUSIC_BUTTON_HEIGHT + layout.height) / 2;
        font.draw(game.batch, musicStatus, textX, textY);

        // Draw back button
        game.batch.draw(backButton,
            13f, WORLD_HEIGHT - BACK_BUTTON_SIZE - 20f,
            BACK_BUTTON_SIZE, BACK_BUTTON_SIZE);

        game.batch.end();
    }

    private void toggleMusic() {
        isMusicPlaying = !isMusicPlaying;
        if (isMusicPlaying) {
            game.resumeMusic();
        } else {
            game.pauseMusic();
        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void dispose() {
        if (musicToggleButton != null) musicToggleButton.dispose();
        if (backButton != null) backButton.dispose();
        if (backgroundTexture != null) backgroundTexture.dispose();
        if (font != null) font.dispose();
    }

    @Override public void show() {
        isMusicPlaying = game.isMusicPlaying();
    }

    @Override public void hide() {}
    @Override public void pause() {}
    @Override public void resume() {}
}
