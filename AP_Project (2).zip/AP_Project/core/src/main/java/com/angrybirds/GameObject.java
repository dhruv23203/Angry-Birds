package com.angrybirds;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Json;

public abstract class GameObject implements Json.Serializable {
    protected float x, y;
    protected float width, height;
    protected TextureRegion texture;

    public GameObject(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getX() { return x; }
    public float getY() { return y; }
    public float getWidth() { return width; }
    public float getHeight() { return height; }
    public TextureRegion getTexture() { return texture; }
    public abstract void dispose();
    public abstract void loadTexture();
}
