package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

public class SteelBlock extends Block {
    public SteelBlock(float x, float y) {
        super(x, y, 250);
        loadTexture();
    }

    @Override
    public void loadTexture() {
        texture = new TextureRegion(new Texture(Gdx.files.internal("steel.png")));
    }
    @Override
    public void dispose() {
        if (texture != null) {
            texture.getTexture().dispose();
        }
    }

    @Override
    public void write(Json json) {
        json.writeValue("x", getX());
        json.writeValue("y", getY());
        json.writeValue("health", getHealth());
        json.writeValue("type", "SteelBlock");
    }

    @Override
    public void read(Json json, JsonValue jsonValue) {
        setX(jsonValue.getFloat("x"));
        setY(jsonValue.getFloat("y"));
        setHealth(jsonValue.getFloat("health"));
        json.writeValue("type", "STEEL");
        loadTexture();
    }
}
