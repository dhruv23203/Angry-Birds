package com.angrybirds;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class PauseScreen3 implements Screen , Serializable {
    private final MyAngryBirdGame game;
    private OrthographicCamera camera;
    private Viewport viewport;
    private Texture resumeButton, restartButton, mainMenuButton;
    private Texture backgroundTexture;
    private Rectangle resumeBounds, restartBounds, mainMenuBounds;
    private Vector3 touchPoint;
    protected String filename = "save/pauseState3.json";


    private static final float WORLD_WIDTH = 1390f;
    private static final float WORLD_HEIGHT = 720f;

    // Button positions
    private static final float CENTER_X = 412f;  // (WORLD_WIDTH - buttonWidth) / 2
    private static final float RESUME_Y = 500f;
    private static final float RESTART_Y = 285f;  // 300f - 15f
    private static final float MAIN_MENU_Y = 70f; // 100f - (2 * 15f)

    // Button dimensions
    private static final float BUTTON_WIDTH = 417f;  // 0.3f * WORLD_WIDTH
    private static final float BUTTON_HEIGHT = 216f; // 0.3f * WORLD_HEIGHT

    public PauseScreen3(MyAngryBirdGame game) {
        this.game = game;
        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        camera.position.set(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 0);
        viewport.apply();

        touchPoint = new Vector3();

        // Load textures
        backgroundTexture = new Texture("background2.png");
        resumeButton = new Texture("resume.png");
        restartButton = new Texture("restart.png");
        mainMenuButton = new Texture("mainmenu.png");

        // Position buttons
        resumeBounds = new Rectangle(CENTER_X + 70f, RESUME_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
        restartBounds = new Rectangle(CENTER_X + 70f, RESTART_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
        mainMenuBounds = new Rectangle(CENTER_X + 70f, MAIN_MENU_Y, BUTTON_WIDTH, BUTTON_HEIGHT);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        if (Gdx.input.justTouched()) {
            touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0);
            viewport.unproject(touchPoint);

            // All buttons share the same X range
            if (touchPoint.y >= RESUME_Y + 60f && touchPoint.y <= RESUME_Y + BUTTON_HEIGHT - 60f) {
                try {
                    GameScreen3 savedGame = GameState3.loadGame(filename, game);
                    dispose();
                    game.setScreen(savedGame);
                } catch (Exception e) {
                    System.err.println("Error loading saved game: " + e.getMessage());
                    // Fallback to new game if load fails
                    game.setScreen(new GameScreen3(game));
                }
                return;
            }
            // Restart button
            else if (touchPoint.y >= RESTART_Y + 60f && touchPoint.y <= RESTART_Y + BUTTON_HEIGHT - 60f) {
                dispose();
                game.setScreen(new GameScreen3(game));
                return;
            }
            // Main Menu button
            else if (touchPoint.y >= MAIN_MENU_Y  + 60f && touchPoint.y <= MAIN_MENU_Y + BUTTON_HEIGHT - 60f ) {
                try {
                    String saveDir = "save";
                    if (!Gdx.files.local(saveDir).exists()) {
                        Gdx.files.local(saveDir).mkdirs();
                    }

                    // Use a simple filename in the save directory
                    String saveFile = saveDir + "/game3.json";
                    System.out.println("Saving game state to: " + saveFile);
                    GameScreen3 savedGame = GameState3.loadGame(filename, game);
                    GameState3.saveGame(savedGame,saveFile);
                    dispose();
                    game.setScreen(new MainMenuScreen(game));
                } catch (Exception e) {
                    System.err.println("Error loading saved game: " + e.getMessage());
                    // Fallback to new game if load fails
                    game.setScreen(new GameScreen3(game));
                }
                return;

            }

        }

        game.batch.begin();
        // Draw background
        game.batch.draw(backgroundTexture, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);

        // Draw the buttons
        game.batch.draw(resumeButton, resumeBounds.x, resumeBounds.y,
            resumeBounds.width, resumeBounds.height);
        game.batch.draw(restartButton, restartBounds.x, restartBounds.y,
            restartBounds.width, restartBounds.height);
        game.batch.draw(mainMenuButton, mainMenuBounds.x, mainMenuBounds.y,
            mainMenuBounds.width, mainMenuBounds.height);

        game.batch.end();
    }




    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void dispose() {
        if (backgroundTexture != null) backgroundTexture.dispose();
        if (resumeButton != null) resumeButton.dispose();
        if (restartButton != null) restartButton.dispose();
        if (mainMenuButton != null) mainMenuButton.dispose();
    }

    @Override
    public void show() {
        camera.position.set(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 0);
        camera.update();
    }

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}
}

