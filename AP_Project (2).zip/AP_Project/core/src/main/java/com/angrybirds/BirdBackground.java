package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

public class BirdBackground implements Json.Serializable {
    private float width;
    private float height;
    private Rectangle bounds;
    private Texture texture;



    public BirdBackground(float x, float y, float width, float height) {
        this.bounds = new Rectangle(x, y, width, height);
        loadTexture();
    }

    public void loadTexture() {
        texture = new TextureRegion(new Texture(Gdx.files.internal("bird_background.png"))).getTexture();
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void setBounds(Rectangle bounds) {
        this.bounds = bounds;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public Texture getTexture() {
        return texture;
    }

    public void setTexture(Texture texture) {
        this.texture = texture;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public void dispose() {
        if (texture != null) {
            texture.dispose();
            texture = null;
        }
    }

    // Getters and setters
    public float getX() { return bounds.x; }
    public float getY() { return bounds.y; }
    public float getWidth() { return bounds.width; }
    public float getHeight() { return bounds.height; }

    public void setPosition(float x, float y) {
        bounds.x = x;
        bounds.y = y;
    }

    public void setSize(float width, float height) {
        bounds.width = width;
        bounds.height = height;
    }

    @Override
    public void write(Json json) {
        json.writeObjectStart();
        json.writeValue("x", bounds.x);
        json.writeValue("y", bounds.y);
        json.writeValue("width", bounds.width);
        json.writeValue("height", bounds.height);
        json.writeObjectEnd();
    }



    @Override
    public void read(Json json, JsonValue jsonData) {
        bounds = new Rectangle(
            jsonData.getFloat("x"),
            jsonData.getFloat("y"),
            jsonData.getFloat("width"),
            jsonData.getFloat("height")
        );

        loadTexture();
    }

    public boolean contains(float x, float y) {
        if (bounds.contains(x, y)) {
            return true;
        }
        return false;
    }
}
