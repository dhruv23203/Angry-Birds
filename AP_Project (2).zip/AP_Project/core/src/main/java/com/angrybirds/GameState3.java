package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;
import com.badlogic.gdx.utils.viewport.Viewport;
import java.util.*;

public class GameState3 implements Json.Serializable {
    // Game objects
    private final List<Bird> birds;
    private final List<Pig> pigs;
    private final List<Block> blocks;
    private final List<BirdBackground> birdBackgrounds;
    private final Map<GameScreen3.BirdType, Integer> birdCounts;
    private Catapult catapult;
    private Bird activeBird;





    // Camera and viewport state
    private float cameraX;
    private float cameraY;
    private float cameraZoom;
    private float viewportWidth;
    private float viewportHeight;

    // Constructor
    public GameState3() {
        this.birds = new ArrayList<>();
        this.pigs = new ArrayList<>();
        this.blocks = new ArrayList<>();
        this.birdBackgrounds = new ArrayList<>();
        this.birdCounts = new HashMap<>();
    }

    public void captureState(GameScreen3 screen) {
        if (screen == null) {
            throw new IllegalArgumentException("Screen cannot be null");
        }

        captureGameObjects(screen);
        captureCameraState(screen);
        captureViewportState(screen);
    }

    private void captureGameObjects(GameScreen3 screen) {
        birds.clear();
        birds.addAll(screen.getBirds());

        pigs.clear();
        pigs.addAll(screen.getPigs());

        blocks.clear();
        blocks.addAll(screen.getBlocks());

        birdBackgrounds.clear();
        birdBackgrounds.addAll(screen.getBirdBackgrounds());

        catapult = screen.getCatapult();
        activeBird = screen.getActiveBird();

        birdCounts.clear();
        birdCounts.putAll(screen.getBirdCounts());


    }


    private void captureCameraState(GameScreen3 screen) {
        OrthographicCamera camera = screen.getCamera();
        if (camera != null) {
            cameraX = camera.position.x;
            cameraY = camera.position.y;
            cameraZoom = camera.zoom;
        }
    }

    private void captureViewportState(GameScreen3 screen) {
        Viewport viewport = screen.getViewport();
        if (viewport != null) {
            viewportWidth = viewport.getWorldWidth();
            viewportHeight = viewport.getWorldHeight();
        }
    }

    public void restoreState(GameScreen3 screen) {
        if (screen == null) {
            throw new IllegalArgumentException("Screen cannot be null");
        }

        restoreGameObjects(screen);
        restoreCameraState(screen);
        restoreViewportState(screen);
    }

    private void restoreGameObjects(GameScreen3 screen) {
        screen.setBirds(new ArrayList<>(birds));
        screen.setPigs(new ArrayList<>(pigs));
        screen.setBlocks(new ArrayList<>(blocks));
        screen.setBirdBackgrounds(new ArrayList<>(birdBackgrounds));
        screen.setCatapult(catapult);
        screen.setActiveBird(activeBird);

        Map<GameScreen3.BirdType, Integer> screenBirdCounts = screen.getBirdCounts();
        screenBirdCounts.clear();
        screenBirdCounts.putAll(birdCounts);


    }

    private void restoreCameraState(GameScreen3 screen) {
        OrthographicCamera camera = screen.getCamera();
        if (camera != null) {
            camera.position.x = cameraX;
            camera.position.y = cameraY;
            camera.zoom = cameraZoom;
            camera.update();
        }
    }

    private void restoreViewportState(GameScreen3 screen) {
        Viewport viewport = screen.getViewport();
        if (viewport != null) {
            viewport.setWorldSize(viewportWidth, viewportHeight);
            viewport.update(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), true);
        }
    }

    @Override
    public void write(Json json) {
        writeCameraState(json);
        writeGameObjects(json);
        writeBirdCounts(json);

    }

    private void writeCameraState(Json json) {
        json.writeValue("cameraX", cameraX);
        json.writeValue("cameraY", cameraY);
        json.writeValue("cameraZoom", cameraZoom);
        json.writeValue("viewportWidth", viewportWidth);
        json.writeValue("viewportHeight", viewportHeight);
    }

    private void writeGameObjects(Json json) {
        writeArray(json, "birds", birds);
        writeArray(json, "pigs", pigs);
        writeArray(json, "blocks", blocks);

        json.writeArrayStart("birdBackgrounds");
        for (BirdBackground background : birdBackgrounds) {
            json.writeObjectStart();
            json.writeValue("x", background.getX());
            json.writeValue("y", background.getY());
            json.writeValue("width", background.getWidth());
            json.writeValue("height", background.getHeight());
            json.writeObjectEnd();
        }
        json.writeArrayEnd();

        // Write catapult data
        json.writeObjectStart("catapult");
        if (catapult != null) {
            json.writeValue("x", catapult.getX());
            json.writeValue("y", catapult.getY());

        }
        json.writeObjectEnd();
        json.writeValue("activeBirdIndex", birds.indexOf(activeBird));
    }

    private void writeArray(Json json, String name, List<?> items) {
        json.writeArrayStart(name);
        for (Object item : items) {
            writeGameObject(json, item);
        }
        json.writeArrayEnd();
    }

    private void writeGameObject(Json json, Object gameObject) {
        json.writeObjectStart();
        if (gameObject instanceof Bird) {
            writeBird(json, (Bird) gameObject);
        } else if (gameObject instanceof Pig) {
            writePig(json, (Pig) gameObject);
        } else if (gameObject instanceof Block) {
            writeBlock(json, (Block) gameObject);
        }
        json.writeObjectEnd();
    }

    private void writeBird(Json json, Bird bird) {
        json.writeValue("type", bird.getClass().getSimpleName());
        json.writeValue("x", bird.getX());
        json.writeValue("y", bird.getY());
    }

    private void writePig(Json json, Pig pig) {
        json.writeValue("type", getPigType(pig));
        json.writeValue("x", pig.getX());
        json.writeValue("y", pig.getY());
        json.writeValue("health", pig.getHealth());
    }

    private void writeBlock(Json json, Block block) {
        json.writeValue("type", getBlockType(block));
        json.writeValue("x", block.getX());
        json.writeValue("y", block.getY());
        json.writeValue("health", block.getHealth());
    }

    private void writeBirdCounts(Json json) {
        json.writeObjectStart("birdCounts");
        for (Map.Entry<GameScreen3.BirdType, Integer> entry : birdCounts.entrySet()) {
            json.writeValue(entry.getKey().name(), entry.getValue());
        }
        json.writeObjectEnd();
    }

    @Override
    public void read(Json json, JsonValue jsonData) {
        readCameraState(jsonData);
        readGameObjects(jsonData);
        readBirdCounts(jsonData);

    }

    private void readCameraState(JsonValue jsonData) {
        cameraX = jsonData.getFloat("cameraX");
        cameraY = jsonData.getFloat("cameraY");
        cameraZoom = jsonData.getFloat("cameraZoom");
        viewportWidth = jsonData.getFloat("viewportWidth");
        viewportHeight = jsonData.getFloat("viewportHeight");
    }

    private void readGameObjects(JsonValue jsonData) {
        readBirds(jsonData.get("birds"));
        readPigs(jsonData.get("pigs"));
        readBlocks(jsonData.get("blocks"));
        readBirdBackgrounds(jsonData.get("birdBackgrounds"));

        // Read catapult data
        JsonValue catapultData = jsonData.get("catapult");
        if (catapultData != null) {
            catapult = new Catapult(
                catapultData.getFloat("x", 0),
                catapultData.getFloat("y", 0)
            );

        }

        int activeBirdIndex = jsonData.getInt("activeBirdIndex", -1);
        activeBird = (activeBirdIndex >= 0 && activeBirdIndex < birds.size()) ?
            birds.get(activeBirdIndex) : null;
    }

    private void readBirdBackgrounds(JsonValue backgroundArray) {
        birdBackgrounds.clear();
        if (backgroundArray != null) {
            for (JsonValue backgroundData = backgroundArray.child;
                 backgroundData != null;
                 backgroundData = backgroundData.next) {
                float x = backgroundData.getFloat("x");
                float y = backgroundData.getFloat("y");
                float width = backgroundData.getFloat("width");
                float height = backgroundData.getFloat("height");

                BirdBackground background = new BirdBackground(x, y, width, height);
                birdBackgrounds.add(background);
            }
        }
    }


    private void readBirds(JsonValue birdArray) {
        birds.clear();
        for (JsonValue birdData = birdArray.child; birdData != null; birdData = birdData.next) {
            birds.add(createBird(
                birdData.getString("type"),
                birdData.getFloat("x"),
                birdData.getFloat("y")
            ));
        }
    }

    private void readPigs(JsonValue pigArray) {
        pigs.clear();
        for (JsonValue pigData = pigArray.child; pigData != null; pigData = pigData.next) {
            Pig pig = createPig(
                pigData.getString("type"),
                pigData.getFloat("x"),
                pigData.getFloat("y")
            );
            pig.setHealth(pigData.getInt("health", 100));
            pigs.add(pig);
        }
    }

    private void readBlocks(JsonValue blockArray) {
        blocks.clear();
        for (JsonValue blockData = blockArray.child; blockData != null; blockData = blockData.next) {
            Block block = createBlock(
                blockData.getString("type"),
                blockData.getFloat("x"),
                blockData.getFloat("y")
            );
            block.setHealth(blockData.getFloat("health", 100));
            blocks.add(block);
        }
    }



    private void readBirdCounts(JsonValue jsonData) {
        birdCounts.clear();
        JsonValue birdCountsData = jsonData.get("birdCounts");
        for (JsonValue entry = birdCountsData.child; entry != null; entry = entry.next) {
            GameScreen3.BirdType type = GameScreen3.BirdType.valueOf(entry.name);
            birdCounts.put(type, entry.asInt());
        }
    }

    private String getPigType(Pig pig) {
        if (pig instanceof HeadPig) return "HEAD";
        if (pig instanceof SmallPig) return "SMALL";
        if (pig instanceof MediumPig) return "MEDIUM";
        throw new IllegalArgumentException("Unknown pig type: " + pig.getClass().getName());
    }

    private String getBlockType(Block block) {
        if (block instanceof SteelBlock) return "STEEL";
        if (block instanceof WoodenBlock) return "WOODEN";
        if (block instanceof GlassBlock) return "GLASS";
        throw new IllegalArgumentException("Unknown block type: " + block.getClass().getName());
    }

    private Pig createPig(String type, float x, float y) {
        return switch (type) {
            case "HEAD" -> new HeadPig(x, y);
            case "SMALL" -> new SmallPig(x, y);
            case "MEDIUM" -> new MediumPig(x, y);
            default -> throw new IllegalArgumentException("Unknown pig type: " + type);
        };
    }

    private Block createBlock(String type, float x, float y) {
        return switch (type) {
            case "STEEL" -> new SteelBlock(x, y);
            case "WOODEN" -> new WoodenBlock(x, y);
            case "GLASS" -> new GlassBlock(x, y);
            default -> throw new IllegalArgumentException("Unknown block type: " + type);
        };
    }

    private Bird createBird(String type, float x, float y) {
        return switch (type) {
            case "BlackBird" -> new BlackBird(x, y);
            case "RedBird" -> new RedBird(x, y);
            case "BlueBird" -> new BlueBird(x, y);

            default -> throw new IllegalArgumentException("Unknown bird type: " + type);
        };
    }

    // Static helper methods for saving and loading
    public static void saveGame(GameScreen3 screen, String filename) {
        if (screen == null || filename == null || filename.isEmpty()) {
            throw new IllegalArgumentException("Invalid save parameters");
        }

        GameState3 state = new GameState3();
        state.captureState(screen);

        Json json = new Json();
        String jsonString = json.toJson(state);
        Gdx.files.local(filename).writeString(jsonString, false);
    }

    public static GameScreen3 loadGame(String filename, MyAngryBirdGame game) {
        if (filename == null || filename.isEmpty() || game == null) {
            throw new IllegalArgumentException("Invalid load parameters");
        }

        String jsonString = Gdx.files.local(filename).readString();
        Json json = new Json();
        GameState3 state = json.fromJson(GameState3.class, jsonString);

        GameScreen3 newScreen = new GameScreen3(game);
        state.restoreState(newScreen);
        return newScreen;
    }
}

