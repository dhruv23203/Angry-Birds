package com.angrybirds;

import com.angrybirds.MyAngryBirdGame;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class SavedGameScreen implements Screen {
    private final MyAngryBirdGame game;
    private OrthographicCamera camera;
    private Viewport viewport;
    private Texture save1Button;
    private Texture save2Button;
    private Texture save3Button;
    private Texture backButton;
    private Texture background;

    private Rectangle save1Bounds;
    private Rectangle save2Bounds;
    private Rectangle save3Bounds;
    private Rectangle backBounds;

    private Vector3 touchPoint;

    public SavedGameScreen(MyAngryBirdGame game) {
        this.game = game;
        camera = new OrthographicCamera();
        viewport = new FitViewport(1390f, 720f, camera);
        camera.position.set(1390f/2, 720f/2, 0);
        touchPoint = new Vector3();

        background = new Texture("background2.png");
        save1Button = new Texture("save1.png");
        save2Button = new Texture("save2.png");
        save3Button = new Texture("save3.png");
        backButton = new Texture("back.png");

        save1Bounds = new Rectangle(460f, 450f, 450f, 250f);
        save2Bounds = new Rectangle(460f, 250f, 450f, 250f);
        save3Bounds = new Rectangle(460f, 50f, 450f, 250f);
        backBounds = new Rectangle(40f, 600f, 80f, 80f);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        if (Gdx.input.justTouched()) {
            touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0f);
            viewport.unproject(touchPoint);

            // Back button
            if (touchPoint.x >= 40f && touchPoint.x <= 120f &&
                touchPoint.y >= 600f && touchPoint.y <= 680f) {
                dispose();
                game.setScreen(new MainMenuScreen(game));
                return;
            }

            // Check X coordinate once for all save buttons
            if (touchPoint.x >= 470f + 50f && touchPoint.x <= 900f - 40f) {
                // Then check Y coordinates for each button
                if (touchPoint.y >= 450f + 80f && touchPoint.y <= 700f - 70f) {
                    try {
                        GameScreen savedGame = GameState.loadGame("save/game1.json", game);
                        dispose();
                        game.setScreen(savedGame);
                    } catch (Exception e) {
                        System.err.println("Error loading saved game: " + e.getMessage());
                        // Fallback to new game if load fails
                        game.setScreen(new GameScreen(game));
                    }
                    return;
                }
                if (touchPoint.y >= 250f +80f && touchPoint.y <= 500f - 70f) {
                    try {
                        GameScreen2 savedGame = GameState2.loadGame("save/game2.json", game);
                        dispose();
                        game.setScreen(savedGame);
                    } catch (Exception e) {
                        System.err.println("Error loading saved game: " + e.getMessage());
                        // Fallback to new game if load fails
                        game.setScreen(new GameScreen2(game));
                    }
                    return;
                }
                if (touchPoint.y >= 50f + 80f && touchPoint.y <= 300f - 70f ) {
                    try {
                        GameScreen3 savedGame = GameState3.loadGame("save/game3.json", game);
                        dispose();
                        game.setScreen(savedGame);
                    } catch (Exception e) {
                        System.err.println("Error loading saved game: " + e.getMessage());
                        // Fallback to new game if load fails
                        game.setScreen(new GameScreen3(game));
                    }
                    return;
                }
            }
        }

        game.batch.begin();
        game.batch.draw(background, 0, 0, 1390f, 720f);

        game.batch.draw(save1Button, save1Bounds.x, save1Bounds.y, save1Bounds.width, save1Bounds.height);
        game.batch.draw(save2Button, save2Bounds.x, save2Bounds.y, save2Bounds.width, save2Bounds.height);
        game.batch.draw(save3Button, save3Bounds.x, save3Bounds.y, save3Bounds.width, save3Bounds.height);
        game.batch.draw(backButton, backBounds.x, backBounds.y, backBounds.width, backBounds.height);

        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void dispose() {
        background.dispose();
        save1Button.dispose();
        save2Button.dispose();
        save3Button.dispose();
        backButton.dispose();
    }

    @Override
    public void show() {}

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}
}
