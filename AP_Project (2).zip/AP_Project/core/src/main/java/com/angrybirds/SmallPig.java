package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

public class SmallPig extends Pig {
    public SmallPig(float x, float y) {
        super(x, y, 35, 150);
        loadTexture();
    }

    @Override
    public void loadTexture() {
        texture = new TextureRegion(new Texture(Gdx.files.internal("smallpig.png")));
    }
    @Override
    public void dispose() {
        if (texture != null) {
            texture.getTexture().dispose();
        }
    }

    @Override
    public void write(Json json) {
        json.writeValue("x", getX());
        json.writeValue("y", getY());
        json.writeValue("health", getHealth());
        json.writeValue("type", "SmallPig");
    }

    @Override
    public void read(Json json, JsonValue jsonValue) {
        setX(jsonValue.getFloat("x"));
        setY(jsonValue.getFloat("y"));
        setHealth((int) jsonValue.getFloat("health"));
        json.writeValue("type", "SMALL");
        loadTexture();

    }
}
