package com.angrybirds;

import com.badlogic.gdx.math.Rectangle;

import java.util.List;

import static com.angrybirds.Bird.GRAVITY;

public abstract class Block extends GameObject {
    protected float durability;
    protected float currentDurability;
    protected float velocityY;
    protected boolean isUnstable;
    private Bird lastCollidedBird;

    public Block(float x, float y, float durability) {
        super(x, y, 70, 70);
        this.durability = durability;
        this.currentDurability = durability;
        velocityY = 0;
        isUnstable = false;
        lastCollidedBird = null;
    }
    public boolean handleBirdCollision(Bird bird) {
        Rectangle blockBounds = new Rectangle(x, y, width, height);
        Rectangle birdBounds = new Rectangle(bird.getX(), bird.getY(), bird.getWidth(), bird.getHeight());

        if (blockBounds.overlaps(birdBounds)) {
            // Apply damage if it's the first hit
            if (lastCollidedBird != bird) {
                if (!bird.hasFirstImpact()) {
                    takeDamage(bird.getHitPower());
                    lastCollidedBird = bird;
                } else {
                    takeDamage(bird.getLightImpactPower());
                }
            }

            // Calculate collision response for the last frame
            float collisionX = bird.getX() + bird.getWidth() / 2;
            float collisionY = bird.getY() + bird.getHeight() / 2;
            float deltaX = collisionX - (x + width / 2);
            float deltaY = collisionY - (y + height / 2);

            // Apply final position adjustment
            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                if (deltaX > 0) {
                    bird.setX(x + width);
                } else {
                    bird.setX(x - bird.getWidth());
                }
            } else {
                if (deltaY > 0) {
                    bird.setY(y + height);
                    bird.getVelocity().y = 0;
                } else {
                    bird.setY(y - bird.getHeight());
                    bird.getVelocity().y = 0;
                }
            }

            // Handle collision and mark bird as used
            bird.handleBlockCollision();
            return true;
        }
        return false;
    }


    public abstract void dispose();

    public float getVelocityY() {
        return velocityY;
    }

    public void setVelocityY(float velocityY) {
        this.velocityY = velocityY;
    }

    public void takeDamage(float damage) {
        currentDurability -= damage;
        if (currentDurability <= 0) {
            isUnstable = true;
        }
    }

    public boolean isDestroyed() {
        return currentDurability <= 0;
    }

    public boolean isUnstable() {
        return isUnstable;
    }

    public void updatePosition(float delta,List<Block> blocks,float VELOCITY_DAMAGE_THRESHOLD ) {
        if (isUnstable) {
            // Apply gravity and update position
            velocityY += GRAVITY * delta;
            setY(getY() + velocityY * delta);

            // Check for collision with ground or other blocks
            checkCollisions(blocks,VELOCITY_DAMAGE_THRESHOLD);
        }
    }

    private void checkCollisions(List<Block> blocks,float VELOCITY_DAMAGE_THRESHOLD) {
        // Check for collision with ground
        if (getY() <= 70f) {
            setY(70f);
            velocityY = 0;
        } else {
            // Check for collision with blocks below
            for (Block block : blocks) {
                if (block != this && !block.isDestroyed() && checkCollision(block)) {
                    setY(block.getY() + block.getHeight());
                    velocityY = 0;
                    break;
                }
            }
        }

        // If block has fallen too fast, take damage
        if (Math.abs(velocityY) > VELOCITY_DAMAGE_THRESHOLD) {
            takeDamage(1);
        }
    }
    public float getHealth() {  // Added getter for health
        return currentDurability;
    }

    public void setHealth(float health) {  // Added setter for health
        this.currentDurability = health;
        if (this.currentDurability <= 0) {
            this.currentDurability = 0;
            this.isUnstable = true;
        }
    }

    private boolean checkCollision(Block other) {
        return getX() < other.getX() + other.getWidth() && getX() + getWidth() > other.getX() &&
            getY() < other.getY() + other.getHeight() && getY() + getHeight() > other.getY();
    }
}
