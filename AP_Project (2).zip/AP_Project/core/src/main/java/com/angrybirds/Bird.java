package com.angrybirds;

import com.badlogic.gdx.math.Vector2;
import java.util.ArrayList;

public abstract class Bird extends GameObject {
    protected boolean isLaunched;
    protected boolean isSelected;
    protected boolean isUsed;
    protected Vector2 velocity;
    protected Vector2 position;
    protected static final float GRAVITY = -9.8f * 10;
    protected static final int MAX_DRAG_DISTANCE = 40;
    protected boolean isDragging;
    private float initialX, initialY;
    private float catapultX, catapultY;
    protected int hitPower;
    private static final float VELOCITY_DAMPING = 0.7f; // Velocity reduction on collision
    private static final float MIN_X_VELOCITY = 5f; // Minimum x velocity before falling
    private boolean hasFirstImpact = false;
    private static final float POST_IMPACT_DAMPING = 0.3f; // Stronger damping after first impact
    private static final float LIGHT_IMPACT_POWER = 0.1f; // Very light damage for secondary collisions

    public boolean isDragging() {
        return isDragging;
    }

    public boolean isLaunched() {
        return isLaunched;
    }


    public Bird(float x, float y , int hitPower) {
        super(x, y, 50, 50);
        this.isLaunched = false;
        this.isSelected = false;
        this.isUsed = false;
        this.velocity = new Vector2(0, 0);
        this.position = new Vector2(x, y);
        this.isDragging = false;
        this.initialX = x;
        this.initialY = y;
        this.hitPower = hitPower;
    }
    public abstract void useSpecialPower(); // Added for bird special abilities


    public void setCatapultPosition(float x, float y) {
        this.catapultX = x;
        this.catapultY = y;
    }

    public void select() {
        if (!isUsed && !isLaunched) {
            isSelected = true;
            x = catapultX + 20;
            y = catapultY + 80;
            position.set(x, y);
            initialX = x;
            initialY = y;
        }
    }

    public void deselect() {
        isSelected = false;
        if (!isLaunched) {
            reset();
        }
    }
    public Vector2 getVelocity() {
        return velocity;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public boolean isUsed() {
        return isUsed;
    }

    public void update(float delta) {
        if (isLaunched) {
            velocity.y += GRAVITY * delta;
            position.x += velocity.x * delta;
            position.y += velocity.y * delta;
            x = position.x;
            y = position.y;

            // Check if bird has hit ground without hitting anything
            if (y < 70) {
                isUsed = true;  // Mark as used immediately
                isLaunched = false;
                return;  // Exit update to prevent further movement
            }

            // Check if bird is out of bounds
            if (x > 1200 || x < 0) {
                isUsed = true;
                isLaunched = false;
            }
        }
    }

    public void drag(float mouseX, float mouseY) {
        if (isDragging && !isLaunched && isSelected) {
            float dragX = initialX - mouseX;
            float dragY = initialY - mouseY;

            float dragDistance = (float) Math.sqrt(dragX * dragX + dragY * dragY);
            if (dragDistance > MAX_DRAG_DISTANCE) {
                float scale = MAX_DRAG_DISTANCE / dragDistance;
                dragX *= scale;
                dragY *= scale;
            }

            x = initialX - dragX;
            y = initialY - dragY;
            position.set(x, y);
        }
    }

    public void startDrag() {
        if (isSelected && !isLaunched) {
            isDragging = true;
        }
    }

    public void launch() {
        if (isDragging && !isLaunched && isSelected) {
            float launchX = initialX - x;
            float launchY = initialY - y;

            float velocityScale = 8f;
            velocity.x = launchX * velocityScale;
            velocity.y = launchY * velocityScale;

            isLaunched = true;
            isDragging = false;
//            isUsed = true;
        }
    }
    public void handleBlockCollision() {
        // Mark bird as used immediately after any collision
        isUsed = true;
        isLaunched = false;

        // Keep the collision physics for visual effect during the last frame
        if (!hasFirstImpact) {
            velocity.x *= VELOCITY_DAMPING;
            if (velocity.y < 0) {
                velocity.y = -velocity.y * 0.3f;
            }
            hasFirstImpact = true;
        } else {
            velocity.x *= POST_IMPACT_DAMPING;
            if (velocity.y < 0) {
                velocity.y = -velocity.y * 0.1f;
            }
        }

        if (Math.abs(velocity.x) < MIN_X_VELOCITY) {
            velocity.x = 0;
        }
    }


    // Add getter for first impact status
    public boolean hasFirstImpact() {
        return hasFirstImpact;
    }

    // Add getter for light impact power
    public float getLightImpactPower() {
        return LIGHT_IMPACT_POWER;
    }

    // Reset method needs to reset the first impact flag


//    public void handleBlockCollision() {
//        // Reduce horizontal velocity on impact
//        velocity.x *= VELOCITY_DAMPING;
//
//        // If horizontal velocity becomes too low, bird starts falling
//        if (Math.abs(velocity.x) < MIN_X_VELOCITY) {
//            velocity.x = 0;
//        }
//
//        // Reverse vertical velocity slightly for a small bounce effect
//        if (velocity.y < 0) {
//            velocity.y = -velocity.y * 0.3f;
//        }
//    }

    public int getHitPower() {
        return hitPower;
    }

    public void setUsed(boolean used) {
        isUsed = used;
    }

    public Vector2 getPosition() {
        return position;
    }

    public void setPosition(Vector2 position) {
        this.position = position;
    }


    public void setVelocity(Vector2 velocity) {
        this.velocity = velocity;
    }

    public void setX(float initialX) {
        this.initialX = initialX;
    }

    public void setY(float initialY) {
        this.initialY = initialY;
    }

    public ArrayList<Vector2> predictTrajectory() {
        ArrayList<Vector2> trajectoryPoints = new ArrayList<>();
        if (!isLaunched && isDragging && isSelected) {
            float launchX = initialX - x;
            float launchY = initialY - y;
            float velocityScale = 25f;

            float simX = x;
            float simY = y;
            float simVelX = launchX * velocityScale;
            float simVelY = launchY * velocityScale;
            float timeStep = 1/30f;

            for (int i = 0; i < 15; i++) {
                trajectoryPoints.add(new Vector2(simX, simY));
                simVelY += 3.2 *GRAVITY * timeStep;
                simX += simVelX * timeStep;
                simY += simVelY * timeStep;
            }
        }
        return trajectoryPoints;
    }

    public void reset() {
        x = initialX;
        y = initialY;
        position.set(initialX, initialY);
        velocity.set(0, 0);
        isDragging = false;
        isLaunched = false;
        isSelected = false;
        isUsed = false;
        hasFirstImpact = false;
    }


}
