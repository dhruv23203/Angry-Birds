package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class WinningScreen2 implements Screen {
    private final MyAngryBirdGame game;
    private OrthographicCamera camera;
    private Viewport viewport;
    private Texture backgroundTexture;
    private Texture nextButtonTexture;
    private Texture menuButtonTexture;
    private Vector3 touchPos;

    private static final float WORLD_WIDTH = 1200f;
    private static final float WORLD_HEIGHT = 619f;

    // Button dimensions and positions
    private static final float BUTTON_WIDTH = 350f;
    private static final float BUTTON_HEIGHT = 350f;
    private static final float BUTTON_Y = 80f;
    private static final float NEXT_BUTTON_X = 850f;
    private static final float MENU_BUTTON_X = 130f;

    public WinningScreen2(MyAngryBirdGame game) {
        this.game = game;
        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        camera.position.set(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 0);
        backgroundTexture = new Texture("winning_background.png");
        nextButtonTexture = new Texture("next.png");
        menuButtonTexture = new Texture("mainmenu.png");
        touchPos = new Vector3();
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        if (Gdx.input.justTouched()) {
            touchPos.set(Gdx.input.getX(), Gdx.input.getY(), 0);
            viewport.unproject(touchPos);

            // Using integer checks for Y first (shared by both buttons)
            if (touchPos.y >= BUTTON_Y - 70f && touchPos.y <= (BUTTON_Y + BUTTON_HEIGHT) - 290f) {
                // Next button X check
                if (touchPos.x >= NEXT_BUTTON_X + 50f  && touchPos.x <= (NEXT_BUTTON_X + BUTTON_WIDTH) - 45f ) {
                    dispose();
                    game.setScreen(new GameScreen3(game));
                    return;
                }
                // Menu button X check
                else if (touchPos.x >= MENU_BUTTON_X - 70f && touchPos.x <= (MENU_BUTTON_X + BUTTON_WIDTH) - 165f) {
                    dispose();
                    game.setScreen(new MainMenuScreen(game));
                    return;
                }
            }
        }

        game.batch.begin();
        game.batch.draw(backgroundTexture, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);
        game.batch.draw(nextButtonTexture, NEXT_BUTTON_X , BUTTON_Y - 180f, BUTTON_WIDTH, BUTTON_HEIGHT);
        game.batch.draw(menuButtonTexture, MENU_BUTTON_X - 120f , BUTTON_Y -180f, BUTTON_WIDTH, BUTTON_HEIGHT);
        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    @Override
    public void show() {}

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void dispose() {
        backgroundTexture.dispose();
        nextButtonTexture.dispose();
        menuButtonTexture.dispose();
    }
}

