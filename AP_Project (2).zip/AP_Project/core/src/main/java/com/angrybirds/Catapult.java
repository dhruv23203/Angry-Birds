package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

public class Catapult extends GameObject {
    public Catapult(float x, float y) {
        super(x, y, 60, 120);
        loadTexture();
    }

    @Override
    public void loadTexture() {
        texture = new TextureRegion(new Texture(Gdx.files.internal("catapult.png")));
    }
    @Override
    public void dispose() {
        if (texture != null) {
            texture.getTexture().dispose();
        }
    }

    @Override
    public void write(Json json) {
        // Write the position and dimensions
        json.writeValue("x", getX());
        json.writeValue("y", getY());
        json.writeValue("width", getWidth());
        json.writeValue("height", getHeight());

    }

    @Override
    public void read(Json json, JsonValue jsonValue) {
        // Read the position and dimensions
        setX(jsonValue.getFloat("x"));
        setY(jsonValue.getFloat("y"));
        json.writeValue("type", "Catapult");

        // Reload the texture since it's not serialized
        loadTexture();
    }
}
