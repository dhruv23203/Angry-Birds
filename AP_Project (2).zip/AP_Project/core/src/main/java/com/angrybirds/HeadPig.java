package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Json;
import com.badlogic.gdx.utils.JsonValue;

public class HeadPig extends Pig {
    public HeadPig(float x, float y) {
        super(x, y, 65, 300);
        loadTexture();
    }

    @Override
    public void loadTexture() {
        texture = new TextureRegion(new Texture(Gdx.files.internal("headpig.png")));
    }
    @Override
    public void dispose() {
        if (texture != null) {
            texture.getTexture().dispose();
        }
    }

    @Override
    public void write(Json json) {
        json.writeValue("x", getX());
        json.writeValue("y", getY());
        json.writeValue("health", getHealth());
        json.writeValue("type", "HeadPig");
    }

    @Override
    public void read(Json json, JsonValue jsonValue) {
        setX(jsonValue.getFloat("x"));
        setY(jsonValue.getFloat("y"));
        json.writeValue("type", "HEAD");
        setHealth((int) jsonValue.getFloat("currentHealth"));
        loadTexture();

    }
}
