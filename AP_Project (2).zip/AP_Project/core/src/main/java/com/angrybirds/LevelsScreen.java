package com.angrybirds;

import com.angrybirds.MyAngryBirdGame;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class LevelsScreen implements Screen {
    private final MyAngryBirdGame game;
    private OrthographicCamera camera;
    private Viewport viewport;
    private Texture level1Button;
    private Texture level2Button;
    private Texture level3Button;
    private Texture backButton;
    private Texture background;

    private Rectangle level1Bounds;
    private Rectangle level2Bounds;
    private Rectangle level3Bounds;
    private Rectangle backBounds;
    private Vector3 touchPoint;

    // Screen dimensions
    private static final float WORLD_WIDTH = 1390f;
    private static final float WORLD_HEIGHT = 720f;

    // Button positions
    private static final float CENTER_X = 412f;  // (1390f - buttonWidth) / 2
    private static final float LEVEL1_Y = 500f;
    private static final float LEVEL2_Y = 285f;  // 300f - 15f
    private static final float LEVEL3_Y = 70f;   // 100f - (2 * 15f)
    private static final float BACK_Y = 620f;

    // Button dimensions
    private static final float LEVEL_BUTTON_WIDTH = 417f;  // 0.3f * 1390f
    private static final float LEVEL_BUTTON_HEIGHT = 216f; // 0.3f * 720f
    private static final float BACK_BUTTON_SIZE = 80f;

    public LevelsScreen(MyAngryBirdGame game) {
        this.game = game;
        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        camera.position.set(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 0);
        touchPoint = new Vector3();

        background = new Texture("background2.png");
        level1Button = new Texture("level1.png");
        level2Button = new Texture("level2.png");
        level3Button = new Texture("level3.png");
        backButton = new Texture("back.png");

        // Position buttons
        level1Bounds = new Rectangle(CENTER_X + 65f, LEVEL1_Y, LEVEL_BUTTON_WIDTH, LEVEL_BUTTON_HEIGHT);
        level2Bounds = new Rectangle(CENTER_X + 65f, LEVEL2_Y, LEVEL_BUTTON_WIDTH, LEVEL_BUTTON_HEIGHT);
        level3Bounds = new Rectangle(CENTER_X + 65f, LEVEL3_Y, LEVEL_BUTTON_WIDTH, LEVEL_BUTTON_HEIGHT);
        backBounds = new Rectangle(13f, BACK_Y, BACK_BUTTON_SIZE, BACK_BUTTON_SIZE);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        if (Gdx.input.justTouched()) {
            touchPoint.set(Gdx.input.getX(), Gdx.input.getY(), 0);
            viewport.unproject(touchPoint);

            // Back button check
            if (touchPoint.x >= 13f && touchPoint.x <= 93f &&
                touchPoint.y >= BACK_Y && touchPoint.y <= BACK_Y + BACK_BUTTON_SIZE) {
                dispose();
                game.setScreen(new MainMenuScreen(game));
                return;
            }

            // Level buttons check - all share same X range
            if (touchPoint.x >= CENTER_X + 130f && touchPoint.x <= CENTER_X + LEVEL_BUTTON_WIDTH ) {
                // Level 1
                if (touchPoint.y >= LEVEL1_Y + 80f && touchPoint.y <= LEVEL1_Y + LEVEL_BUTTON_HEIGHT - 70f) {
                    dispose();
                    game.setScreen(new GameScreen(game));
                    return;
                }
                // Level 2
                else if (touchPoint.y >= LEVEL2_Y  + 80f && touchPoint.y <= LEVEL2_Y + LEVEL_BUTTON_HEIGHT - 70f) {
                    dispose();
                    game.setScreen(new GameScreen2(game));
                    return;
                }
                // Level 3
                else if (touchPoint.y >= LEVEL3_Y  + 80f && touchPoint.y <= LEVEL3_Y + LEVEL_BUTTON_HEIGHT - 70f) {
                    dispose();
                    game.setScreen(new GameScreen3(game));
                    return;
                }
            }
        }

        game.batch.begin();
        game.batch.draw(background, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);

        // Draw the level buttons
        game.batch.draw(level1Button, level1Bounds.x, level1Bounds.y, level1Bounds.width, level1Bounds.height);
        game.batch.draw(level2Button, level2Bounds.x, level2Bounds.y, level2Bounds.width, level2Bounds.height);
        game.batch.draw(level3Button, level3Bounds.x, level3Bounds.y, level3Bounds.width, level3Bounds.height);
        game.batch.draw(backButton, backBounds.x, backBounds.y, backBounds.width, backBounds.height);

        game.batch.end();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void dispose() {
        background.dispose();
        level1Button.dispose();
        level2Button.dispose();
        level3Button.dispose();
        backButton.dispose();
    }

    @Override
    public void show() {}

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}
}
