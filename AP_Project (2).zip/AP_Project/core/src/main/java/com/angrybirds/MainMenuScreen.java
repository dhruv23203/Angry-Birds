package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.graphics.OrthographicCamera;

public class MainMenuScreen implements Screen {
    private final MyAngryBirdGame game;
    private Texture backgroundTexture;
    private Texture newGameButtonTexture;
    private Texture loadGameButtonTexture;
    private Texture exitButtonTexture;
    private Texture settingsButtonTexture;
    private Viewport viewport;
    private OrthographicCamera camera;
    private Vector2 touchPos;
    private Rectangle newGameButton;
    private Rectangle loadGameButton;
    private Rectangle exitButton;
    private Rectangle settingsButton;

    private static final float WORLD_WIDTH = 1390f;
    private static final float WORLD_HEIGHT = 720f;

    // Define Y positions for input handling
    private static final float NEW_GAME_Y = 380f;
    private static final float LOAD_GAME_Y = 204f;
    private static final float EXIT_Y = 28f;
    private static final float SETTINGS_Y = 620f;
    private static final float CENTER_X = 505f;

    public MainMenuScreen(MyAngryBirdGame game) {
        this.game = game;

        // Load textures
        backgroundTexture = new Texture("background.png");
        newGameButtonTexture = new Texture("new_game_button.png");
        loadGameButtonTexture = new Texture("continue.png");
        exitButtonTexture = new Texture("exit.png");
        settingsButtonTexture = new Texture("settings.png");

        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        camera.position.set(WORLD_WIDTH/2, WORLD_HEIGHT/2, 0);
        viewport.apply();

        touchPos = new Vector2();

        // Define consistent button dimensions
        float mainButtonWidth = 380f;
        float mainButtonHeight = 175f;
        float buttonSpacing = 1f;

        // Calculate center X position for all buttons
        float centerX = (WORLD_WIDTH - mainButtonWidth) / 2;

        // Create buttons at specific Y positions for input handling
        newGameButton = new Rectangle(CENTER_X, NEW_GAME_Y, mainButtonWidth, mainButtonHeight);
        loadGameButton = new Rectangle(CENTER_X, LOAD_GAME_Y, mainButtonWidth, mainButtonHeight);
        exitButton = new Rectangle(CENTER_X, EXIT_Y, mainButtonWidth, mainButtonHeight);

        // Settings button in top-right corner
        settingsButton = new Rectangle(1270f, SETTINGS_Y, 80f, 80f);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.BLACK);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();

        // Draw background
        game.batch.draw(backgroundTexture, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);

        // Draw main menu buttons
        game.batch.draw(newGameButtonTexture, newGameButton.x, newGameButton.y,
            newGameButton.width, newGameButton.height);
        game.batch.draw(loadGameButtonTexture, loadGameButton.x, loadGameButton.y,
            loadGameButton.width, loadGameButton.height);
        game.batch.draw(exitButtonTexture, exitButton.x, exitButton.y,
            exitButton.width, exitButton.height);
        game.batch.draw(settingsButtonTexture, settingsButton.x, settingsButton.y,
            settingsButton.width, settingsButton.height);

        game.batch.end();

        // Handle input with explicit coordinates
        if (Gdx.input.justTouched()) {
            touchPos.set(Gdx.input.getX(), Gdx.input.getY());
            viewport.unproject(touchPos);

            // Check if touch is within the horizontal range
            if (touchPos.x >= CENTER_X + 48f && touchPos.x <= CENTER_X + 340f) {
                // Check vertical positions for each button
                if (touchPos.y >= NEW_GAME_Y + 50f && touchPos.y <= NEW_GAME_Y + 100f) {
                    dispose();
                    game.setScreen(new LevelsScreen(game));
                    return;
                } else if (touchPos.y >= LOAD_GAME_Y + 50f && touchPos.y <= LOAD_GAME_Y + 100f) {
                    dispose();
                    game.setScreen(new SavedGameScreen(game));
                    return;
                } else if (touchPos.y >= EXIT_Y + 50f && touchPos.y <= EXIT_Y + 100f) {
                    dispose();
                    Gdx.app.exit();
                }
            }
            // Settings button check with explicit coordinates
            else if (touchPos.x >= 1270f && touchPos.x <= 1350f &&
                touchPos.y >= SETTINGS_Y && touchPos.y <= SETTINGS_Y + 80f) {
                dispose();
                game.setScreen(new SettingsScreen(game));
                return;
            }
        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void dispose() {
        if (backgroundTexture != null) backgroundTexture.dispose();
        if (newGameButtonTexture != null) newGameButtonTexture.dispose();
        if (loadGameButtonTexture != null) loadGameButtonTexture.dispose();
        if (exitButtonTexture != null) exitButtonTexture.dispose();
        if (settingsButtonTexture != null) settingsButtonTexture.dispose();
    }

    @Override
    public void show() {
        camera.position.set(WORLD_WIDTH/2, WORLD_HEIGHT/2, 0);
        camera.update();
    }

    @Override
    public void hide() {}

    @Override
    public void pause() {}

    @Override
    public void resume() {}
}
