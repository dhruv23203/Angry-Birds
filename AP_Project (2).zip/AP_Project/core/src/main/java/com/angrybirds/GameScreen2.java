package com.angrybirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.io.*;
import java.util.*;

import static com.angrybirds.Bird.GRAVITY;

public class GameScreen2 implements Screen , Serializable {
    transient protected MyAngryBirdGame game;
    transient private OrthographicCamera camera;
    transient private Viewport viewport;
    transient private Texture background;
    //    transient private Texture birdBackgroundTexture;
    transient private Texture settingsButtonTexture;
    transient private Texture pauseButtonTexture;
    private Rectangle settingsButton;
    private Rectangle pauseButton;
    private boolean isPaused;

    Catapult catapult;
    List<Bird> birds;
    List<Pig> pigs;
    List<Block> blocks;
    List<BirdBackground> birdBackgrounds;

    private ShapeRenderer shapeRenderer;
    Bird activeBird;

    private static final float WORLD_WIDTH = 1200f;
    private static final float WORLD_HEIGHT = 620f;
    private static final float BIRD_BACKGROUND_WIDTH = 80f;
    private static final float BIRD_BACKGROUND_HEIGHT = 80f;
    private static final float BIRD_WIDTH = 45f;
    private static final float BIRD_HEIGHT = 45f;
    private static final float BIRD_SPACING = 15f;
    private static final float BIRD_START_X = 20f;
    private static final float BIRD_START_Y = 100f;

    private static final float COLLISION_THRESHOLD = 10f;
    private static final float BLOCK_COLLAPSE_THRESHOLD = 1f;
    private static final float VELOCITY_DAMAGE_THRESHOLD = 200f;


    private HashMap<BirdType, Integer> birdCounts;
    protected static enum BirdType { RED, BLUE, BLACK }

    public GameScreen2(MyAngryBirdGame game) {
        this.game = game;
        this.birdCounts = new HashMap<>();
        this.birdCounts.put(BirdType.RED, 10);
        this.birdCounts.put(BirdType.BLUE, 10);
        this.birdCounts.put(BirdType.BLACK, 10);
        setupCamera();
        loadTextures();
        createGameObjects();
        shapeRenderer = new ShapeRenderer();
        createButtons();
    }

    public Texture getBackground() {
        return background;
    }

    public void setBackground(Texture background) {
        this.background = background;
    }



    public OrthographicCamera getCamera() {
        return camera;
    }

    public void setCamera(OrthographicCamera camera) {
        this.camera = camera;
    }

    public Catapult getCatapult() {
        return catapult;
    }

    public void setCatapult(Catapult catapult) {
        this.catapult = catapult;
    }


    public MyAngryBirdGame getGame() {
        return game;
    }

    public void setGame(MyAngryBirdGame game) {
        this.game = game;
    }

    public Texture getPauseButtonTexture() {
        return pauseButtonTexture;
    }

    public void setPauseButtonTexture(Texture pauseButtonTexture) {
        this.pauseButtonTexture = pauseButtonTexture;
    }

    public List<Pig> getPigs() {
        return pigs;
    }

    public void setPigs(List<Pig> pigs) {
        this.pigs = pigs;
    }

    public Rectangle getSettingsButton() {
        return settingsButton;
    }

    public void setSettingsButton(Rectangle settingsButton) {
        this.settingsButton = settingsButton;
    }

    public Texture getSettingsButtonTexture() {
        return settingsButtonTexture;
    }

    public void setSettingsButtonTexture(Texture settingsButtonTexture) {
        this.settingsButtonTexture = settingsButtonTexture;
    }

    public ShapeRenderer getShapeRenderer() {
        return shapeRenderer;
    }

    public void setShapeRenderer(ShapeRenderer shapeRenderer) {
        this.shapeRenderer = shapeRenderer;
    }

    public Bird getActiveBird() {
        return activeBird;
    }

    public void setActiveBird(Bird activeBird) {
        this.activeBird = activeBird;
    }

    public List<BirdBackground> getBirdBackgrounds() {
        return birdBackgrounds;
    }

    public void setBirdBackgrounds(List<BirdBackground> birdBackgrounds) {
        this.birdBackgrounds = birdBackgrounds;
    }

    public void setBirdCounts(HashMap<BirdType, Integer> birdCounts) {
        this.birdCounts = birdCounts;
    }

    public List<Bird> getBirds() {
        return birds;
    }

    public void setBirds(List<Bird> birds) {
        this.birds = birds;
    }

    public List<Block> getBlocks() {
        return blocks;
    }

    public void setBlocks(List<Block> blocks) {
        this.blocks = blocks;
    }

    public boolean isPaused() {
        return isPaused;
    }



    public void setPaused(boolean paused) {
        isPaused = paused;
    }

    public Rectangle getPauseButton() {
        return pauseButton;
    }

    public void setPauseButton(Rectangle pauseButton) {
        this.pauseButton = pauseButton;
    }

    public Viewport getViewport() {
        return viewport;
    }

    public void setViewport(Viewport viewport) {
        this.viewport = viewport;
    }

    private void setupCamera() {
        camera = new OrthographicCamera();
        camera.setToOrtho(false, WORLD_WIDTH, WORLD_HEIGHT);
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
    }

    private void loadTextures() {
        background = new Texture(Gdx.files.internal("background3.png"));
        settingsButtonTexture = new Texture(Gdx.files.internal("settings.png"));
        pauseButtonTexture = new Texture(Gdx.files.internal("pause_button.png"));
    }
    private void createButtons() {
        float buttonSize = BIRD_BACKGROUND_WIDTH;
        float spacing = 10f;
        float topMargin = 20f;

        // Create settings button in top right corner
        settingsButton = new Rectangle(
            WORLD_WIDTH - buttonSize - spacing,
            WORLD_HEIGHT - buttonSize - topMargin,
            buttonSize,
            buttonSize
        );

        // Create pause button to the left of settings button
        pauseButton = new Rectangle(
            WORLD_WIDTH - 2 * buttonSize - 2 * spacing,
            WORLD_HEIGHT - buttonSize - topMargin,
            buttonSize,
            buttonSize
        );
    }
    public Map<BirdType, Integer> getBirdCounts() {
        return birdCounts;
    }
    private void createGameObjects() {
        birds = new ArrayList<>();
        pigs = new ArrayList<>();
        blocks = new ArrayList<>();
        birdBackgrounds = new ArrayList<>();
        catapult = new Catapult(175f, 70f);

        // Only create one background for each bird type that has remaining birds
        float currentY = BIRD_START_Y;

        for (BirdType type : BirdType.values()) {
            if (birdCounts.getOrDefault(type, 0) > 0) {
                birdBackgrounds.add(new BirdBackground(BIRD_START_X, currentY,
                    BIRD_BACKGROUND_WIDTH, BIRD_BACKGROUND_HEIGHT));

                // Calculate center offsets for birds
                float birdCenterOffsetX = (BIRD_BACKGROUND_WIDTH - BIRD_WIDTH) / 2;
                float birdCenterOffsetY = (BIRD_BACKGROUND_HEIGHT - BIRD_HEIGHT) / 2;

                // Create a single bird of this type
                float birdX = BIRD_START_X + birdCenterOffsetX;
                float birdY = currentY + birdCenterOffsetY;

                Bird bird;
                switch (type) {
                    case RED:
                        bird = new RedBird(birdX, birdY);
                        break;
                    case BLUE:
                        bird = new BlueBird(birdX, birdY);
                        break;
                    default:
                        bird = new BlackBird(birdX, birdY);
                        break;
                }
                birds.add(bird);
                bird.setCatapultPosition(catapult.getX(), catapult.getY());
                currentY += BIRD_BACKGROUND_HEIGHT + BIRD_SPACING;
            }
        }

        createLevel();
    }

    private void handleInput() throws IOException {
        if (Gdx.input.justTouched()) {
            Vector3 touchPos = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
            camera.unproject(touchPos);

            // Check for button clicks first
            if (settingsButton.contains(touchPos.x, touchPos.y)) {
                handleSettingsClick();
                return;
            }

            if (pauseButton.contains(touchPos.x, touchPos.y)) {
                handlePauseClick();
                return;
            }

            // Only process game input if not paused
            if (!isPaused) {
                // ... (rest of the existing handleInput logic)
                if (activeBird != null && activeBird.isLaunched()) {
                    return;
                }

                if (activeBird == null || !activeBird.isSelected()) {
                    for (int i = 0; i < birdBackgrounds.size(); i++) {
                        BirdBackground background = birdBackgrounds.get(i);

                        if (background.contains(touchPos.x, touchPos.y)) {
                            BirdType type = getBirdTypeForIndex(i);
                            if (birdCounts.getOrDefault(type, 0) > 0) {
                                if (activeBird != null) {
                                    activeBird.deselect();
                                }

                                Bird newBird = createBirdOfType(type,
                                    background.getX() + (BIRD_BACKGROUND_WIDTH - BIRD_WIDTH) / 2,
                                    background.getY() + (BIRD_BACKGROUND_HEIGHT - BIRD_HEIGHT) / 2);

                                birds.add(newBird);
                                activeBird = newBird;
                                newBird.setCatapultPosition(catapult.getX(), catapult.getY());
                                newBird.select();

                                birdCounts.put(type, birdCounts.get(type) - 1);

                                if (birdCounts.get(type) == 0) {
                                    birdBackgrounds.remove(i);
                                }
                                break;
                            }
                        }
                    }
                } else if (activeBird.isSelected() && !activeBird.isLaunched()) {
                    activeBird.startDrag();
                }
            }
        }

        if (!isPaused) {
            if (Gdx.input.isTouched() && activeBird != null && activeBird.isSelected()) {
                Vector3 touchPos = new Vector3(Gdx.input.getX(), Gdx.input.getY(), 0);
                camera.unproject(touchPos);
                activeBird.drag(touchPos.x, touchPos.y);
            }
            else if (!Gdx.input.isTouched() && activeBird != null && activeBird.isSelected()) {
                activeBird.launch();
                if (activeBird.isLaunched()) {
                    activeBird = null;
                }
            }
        }
    }

    private void handleSettingsClick() {
        System.out.println("Handling settings click");
        try {
            // Create save directory if it doesn't exist
            String saveDir = "save";
            if (!Gdx.files.local(saveDir).exists()) {
                Gdx.files.local(saveDir).mkdirs();
            }

            // Use a simple filename in the save directory
            String saveFile = saveDir + "/settingsState2.json";
            System.out.println("Saving game state to: " + saveFile);

            // Save the game state
            GameState2.saveGame(this, saveFile);
            System.out.println("Game state saved successfully");

            // Switch to settings screen
            dispose();
            game.setScreen(new SettingsLevel2(game));
            System.out.println("Screen changed to SettingsScreen");
        } catch (Exception e) {
            System.err.println("Error in handleSettingsClick: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void handlePauseClick() {
        System.out.println("Handling pause click");
        try {
            // Create save directory if it doesn't exist
            String saveDir = "save";  // This will create a 'save' directory in your game's local storage
            if (!Gdx.files.local(saveDir).exists()) {
                Gdx.files.local(saveDir).mkdirs();
            }

            // Use a simple filename in the save directory
            String saveFile = saveDir + "/pauseState2.json";
            System.out.println("Saving game state to: " + saveFile);

            // Save the game state
            GameState2.saveGame(this, saveFile);
            System.out.println("Game state saved successfully");

            // Set paused and switch screen
            isPaused = true;
            game.setScreen(new PauseScreen2(game));
            System.out.println("Screen changed to PauseScreen");
        } catch (Exception e) {
            System.err.println("Error in handlePauseClick: " + e.getMessage());
            e.printStackTrace();
        }
    }
    private BirdType getBirdTypeForIndex(int index) {
        List<BirdType> availableTypes = new ArrayList<>();
        for (BirdType type : BirdType.values()) {
            if (birdCounts.getOrDefault(type, 0) > 0) {
                availableTypes.add(type);
            }
        }
        return availableTypes.get(index);
    }

    private Bird createBirdOfType(BirdType type, float x, float y) {
        switch (type) {
            case RED:
                return new RedBird(x, y);
            case BLUE:
                return new BlueBird(x, y);
            case BLACK:
                return new BlackBird(x, y);
            default:
                return new RedBird(x, y);
        }
    }

    @Override
    public void render(float delta) {
        // Update physics
        if (!isPaused) {
            updateGameState(delta);
            for (Bird bird : birds) {
                if(!bird.isUsed()) {
                    bird.update(delta);
                }
            }
            for (Block block : blocks) {
                if(!block.isDestroyed()){
                    block.updatePosition(delta,blocks,VELOCITY_DAMAGE_THRESHOLD);
                }
            }
            for (Pig pig : pigs) {
                if(!pig.isDead()){
                    pig.updatePosition(delta,blocks,VELOCITY_DAMAGE_THRESHOLD);
                }
            }
        }

//         Remove used birds
        birds.removeIf(bird -> bird.isUsed() && !bird.isLaunched());

        try {
            handleInput();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        // Clear screen
        Gdx.gl.glClearColor(0.57f, 0.77f, 0.85f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();

        // Draw background
        game.batch.draw(background, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);

        game.batch.draw(settingsButtonTexture,
            settingsButton.x, settingsButton.y,
            settingsButton.width, settingsButton.height);

        game.batch.draw(pauseButtonTexture,
            pauseButton.x, pauseButton.y,
            pauseButton.width, pauseButton.height);

        // Draw catapult
        game.batch.draw(catapult.getTexture(),
            catapult.getX(), catapult.getY(),
            catapult.getWidth(), catapult.getHeight());

        // Draw bird backgrounds and waiting birds
        for (int i = 0; i < birdBackgrounds.size(); i++) {
            BirdBackground background = birdBackgrounds.get(i);
            Bird bird = birds.get(i);

            if (!bird.isSelected() && !bird.isLaunched() && !bird.isUsed()) {
                game.batch.draw(background.getTexture(),
                    background.getX(), background.getY(),
                    background.getWidth(), background.getHeight());

                game.batch.draw(bird.getTexture(),
                    bird.getX(), bird.getY(),
                    BIRD_WIDTH, BIRD_HEIGHT);
            }
        }

        // Draw active and launched birds
        for (Bird bird : birds) {
            game.batch.draw(bird.getTexture(),
                bird.getX(), bird.getY(),
                BIRD_WIDTH, BIRD_HEIGHT);

        }

        // Draw blocks and pigs
        for (Block block : blocks) {
            if(!block.isDestroyed()) {
                game.batch.draw(block.getTexture(),
                    block.getX(), block.getY(),
                    block.getWidth(), block.getHeight());
            }
        }

        for (Pig pig : pigs) {
            if(!pig.isDead()) {
                game.batch.draw(pig.getTexture(),
                    pig.getX(), pig.getY(),
                    pig.getWidth(), pig.getHeight());
            }
        }

        game.batch.end();

        if (!isPaused && activeBird != null && activeBird.isSelected() && !activeBird.isLaunched()) {
            shapeRenderer.setProjectionMatrix(camera.combined);
            shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
            shapeRenderer.setColor(1, 1, 1, 1);
            ArrayList<Vector2> trajectory = activeBird.predictTrajectory();
            for (Vector2 point : trajectory) {
                shapeRenderer.circle(point.x, point.y, 5);
            }
            shapeRenderer.end();
        }

        checkGameStatus();
    }



    private void updateGameState(float delta) {
        // Update bird positions and handle collisions
        Iterator<Bird> birdIterator = birds.iterator();
        while (birdIterator.hasNext()) {
            Bird bird = birdIterator.next();
            if (bird.isLaunched()) {
                // Use the new update method that includes ground collision
                bird.update(delta);

                // Only handle collisions if the bird hasn't hit the ground
                if (!bird.isUsed()) {
                    handleBirdCollisions(bird);
                }
            }
        }

        // Handle block and pig physics
        handleBlockAndPigPhysics(delta);

        // Remove destroyed objects
        removeDestroyedObjects();
    }
    private void handleBirdCollisions(Bird bird) {
        if (!bird.isLaunched()) return;

        // Check collisions with blocks
        for (Block block : blocks) {
            if (block.isDestroyed()) continue;

            // Use the new block collision handler
            if (block.handleBirdCollision(bird)) {
                // Bird collision is now handled inside Block class
                break; // Exit after first collision
            }
        }

        // Check collisions with pigs
        for (Pig pig : pigs) {
            if (pig.isDead()) continue;

            if (checkCollision(bird.getX(), bird.getY(), BIRD_WIDTH, BIRD_HEIGHT,
                pig.getX(), pig.getY(), pig.getWidth(), pig.getHeight())) {

                float velocity = bird.getVelocity().len();
                int damage = calculateDamage(bird, velocity);
                pig.takeDamage(damage);

                // Apply collision physics using the new handler
                bird.handleBlockCollision();
                break; // Exit after first collision
            }
        }
    }

    private void handleBlockAndPigPhysics(float delta) {
        boolean hasCollapse;
        do {
            hasCollapse = false;
            for (Block block : blocks) {
                if (block.isDestroyed()) continue;

                if (isBlockUnstable(block)) {
                    // Damage blocks above
                    List<Block> blocksAbove = getBlocksAbove(block);
                    for (Block upperBlock : blocksAbove) {
                        upperBlock.takeDamage(1);
                    }

                    // Damage pigs above
                    List<Pig> pigsAbove = getPigsAbove(block);
                    for (Pig pig : pigsAbove) {
                        pig.takeDamage(1);
                    }

                    // Apply gravity to unstable blocks
                    block.setVelocityY(block.getVelocityY() + GRAVITY * delta);
                    float newY = block.getY() + block.getVelocityY() * delta;

                    // Check for collision with ground or other blocks
                    if (newY <= 70f) {
                        newY = 70f;
                        block.setVelocityY(0);
                    } else {
                        // Check for collision with blocks below
                        for (Block otherBlock : blocks) {
                            if (otherBlock != block && !otherBlock.isDestroyed() &&
                                checkCollision(block.getX(), newY, block.getWidth(), block.getHeight(),
                                    otherBlock.getX(), otherBlock.getY(),
                                    otherBlock.getWidth(), otherBlock.getHeight())) {
                                newY = otherBlock.getY() + otherBlock.getHeight();
                                block.setVelocityY(0);
                                break;
                            }
                        }
                    }

                    block.setY(newY);

                    // Check if block has fallen too fast
                    if (Math.abs(block.getVelocityY()) > VELOCITY_DAMAGE_THRESHOLD) {
                        block.takeDamage(1);
                    }

                    hasCollapse = true;
                }
            }

            // Update pig positions
            for (Pig pig : pigs) {
                if (!pig.isDead()) {
                    pig.updatePosition(delta, blocks, VELOCITY_DAMAGE_THRESHOLD);
                }
            }
        } while (hasCollapse);
    }

    private boolean isBlockUnstable(Block block) {
        if (block.getY() <= 70f) return false; // Base level blocks are always stable

        // Check if there's any support below
        float blockBottom = block.getY();
        float blockLeft = block.getX();
        float blockRight = block.getX() + block.getWidth();

        for (Block otherBlock : blocks) {
            if (otherBlock == block || otherBlock.isDestroyed()) continue;

            float otherTop = otherBlock.getY() + otherBlock.getHeight();
            float otherLeft = otherBlock.getX();
            float otherRight = otherBlock.getX() + otherBlock.getWidth();

            // Check if this block is directly below and not destroyed
            if (Math.abs(blockBottom - otherTop) < BLOCK_COLLAPSE_THRESHOLD &&
                blockRight > otherLeft && blockLeft < otherRight) {
                return false;
            }
        }
        return true;
    }

    private List<Block> getBlocksAbove(Block block) {
        List<Block> blocksAbove = new ArrayList<>();
        float blockTop = block.getY() + block.getHeight();
        float blockLeft = block.getX();
        float blockRight = block.getX() + block.getWidth();

        for (Block otherBlock : blocks) {
            if (otherBlock == block || otherBlock.isDestroyed()) continue;

            float otherBottom = otherBlock.getY();
            float otherLeft = otherBlock.getX();
            float otherRight = otherBlock.getX() + otherBlock.getWidth();

            if (Math.abs(otherBottom - blockTop) < BLOCK_COLLAPSE_THRESHOLD &&
                otherRight > blockLeft && otherLeft < blockRight) {
                blocksAbove.add(otherBlock);
            }
        }
        return blocksAbove;
    }

    private List<Pig> getPigsAbove(Block block) {
        List<Pig> pigsAbove = new ArrayList<>();
        float blockTop = block.getY() + block.getHeight();
        float blockLeft = block.getX();
        float blockRight = block.getX() + block.getWidth();

        for (Pig pig : pigs) {
            if (pig.isDead()) continue;

            float pigBottom = pig.getY();
            float pigLeft = pig.getX();
            float pigRight = pig.getX() + pig.getWidth();

            if (Math.abs(pigBottom - blockTop) < BLOCK_COLLAPSE_THRESHOLD &&
                pigRight > blockLeft && pigLeft < blockRight) {
                pigsAbove.add(pig);
            }
        }
        return pigsAbove;
    }

    private int calculateDamage(Bird bird, float velocity) {
        int baseDamage = bird.getHitPower();
        if (velocity > VELOCITY_DAMAGE_THRESHOLD) {
            baseDamage *= 2; // Double damage for high-velocity impacts
        }
        return baseDamage;
    }

//    private void handleBirdSpecialAbility(Bird bird) {
//        if (bird instanceof BlackBird) {
//            // Explosion damage to nearby objects
//            handleExplosion(bird.getX(), bird.getY(), 150f);
//        } else if (bird instanceof BlueBird) {
//            // Split into three birds
//            createSplitBirds(bird);
//        }
//    }

    private void handleExplosion(float x, float y, float radius) {
        // Damage blocks in explosion radius
        for (Block block : blocks) {
            if (block.isDestroyed()) continue;

            float distance = Vector2.dst(x, y,
                block.getX() + block.getWidth()/2,
                block.getY() + block.getHeight()/2);

            if (distance <= radius) {
                block.takeDamage(2);
            }
        }

        // Damage pigs in explosion radius
        for (Pig pig : pigs) {
            if (pig.isDead()) continue;

            float distance = Vector2.dst(x, y,
                pig.getX() + pig.getWidth()/2,
                pig.getY() + pig.getHeight()/2);

            if (distance <= radius) {
                pig.takeDamage(2);
            }
        }
    }

//    private void createSplitBirds(Bird originalBird) {
//        // Create two additional birds at slight angles
//        Vector2 velocity = originalBird.getVelocity();
//        float speed = velocity.len();
//        float angle = (float) Math.atan2(velocity.y, velocity.x);
//
//        for (int i = -1; i <= 1; i += 2) {
//            Bird splitBird = new BlueBird(originalBird.getX(), originalBird.getY());
//            float newAngle = angle + (i * 0.2f); // ±0.2 radians deviation
//            splitBird.launch(speed * (float)Math.cos(newAngle),
//                speed * (float)Math.sin(newAngle));
//            birds.add(splitBird);
//        }
//    }

    private boolean checkCollision(float x1, float y1, float w1, float h1,
                                   float x2, float y2, float w2, float h2) {
        return x1 < x2 + w2 && x1 + w1 > x2 &&
            y1 < y2 + h2 && y1 + h1 > y2;
    }



    private void removeDestroyedObjects() {
        blocks.removeIf(Block::isDestroyed);
        pigs.removeIf(Pig::isDead);
    }
    private void createLevel() {
        float blockSize = 70;
        float baseX = 800;
        float baseY = 70;


        // Base layer - three blocks tight together
        blocks.add(new WoodenBlock(baseX, baseY));
        blocks.add(new WoodenBlock(baseX + blockSize , baseY));
        blocks.add(new GlassBlock(baseX + 2 * blockSize , baseY));
        blocks.add(new WoodenBlock(baseX + 3 * blockSize, baseY));

        // Second layer - two blocks centered on base
        blocks.add(new GlassBlock(baseX + blockSize, baseY + blockSize));
        blocks.add(new SteelBlock(baseX + 2 * blockSize, baseY + blockSize));
        blocks.add(new GlassBlock(baseX + 3 * blockSize, baseY + blockSize));

        // Top layer - one block centered
        blocks.add(new WoodenBlock(baseX + 3 * blockSize, baseY + 2 * blockSize));

        blocks.add(new GlassBlock(baseX + 3 * blockSize, baseY + 3 * blockSize));

        blocks.add(new WoodenBlock(baseX + 3 * blockSize, baseY + 4 * blockSize));

        // Place pigs tightly between blocks
        pigs.add(new SmallPig(baseX + blockSize - 37, baseY + blockSize - 15));
        pigs.add(new MediumPig(baseX + 3 * blockSize - 65, baseY + 2 * blockSize - 20));
        pigs.add(new HeadPig(baseX + 3 * blockSize - 10, baseY + 5 * blockSize - 55));
    }


    private void checkGameStatus() {
        boolean allPigsDestroyed = pigs.stream().allMatch(Pig::isDead);

        // Check launched birds and remaining bird counts
        boolean allLaunchedBirdsUsed = birds.stream()
            .filter(Bird::isLaunched)
            .allMatch(Bird::isUsed);

        boolean noRemainingBirds = birdCounts.values().stream()
            .mapToInt(Integer::intValue)
            .sum() == 0;

        // Check if active bird exists and is still being used
        boolean hasActiveBirdInUse = activeBird != null && !activeBird.isUsed();

        // Using the new isUsed flag to check game end conditions
        boolean allBirdsStopped = birds.stream()
            .filter(Bird::isLaunched)
            .allMatch(Bird::isUsed);

        if (allLaunchedBirdsUsed && noRemainingBirds && !hasActiveBirdInUse && allBirdsStopped && !allPigsDestroyed) {
            game.setScreen(new LosingScreen2(game));
            dispose();
        } else if (allPigsDestroyed) {
            game.setScreen(new WinningScreen2(game));
            dispose();
        }
    }
    public void saveGame(String filename) throws IOException {
        GameState2.saveGame(this, filename);
    }

    protected void reloadTextures() {
        // Reload all textures after deserialization
        for (Bird bird : birds) {
            bird.loadTexture();
        }
        for (Block block : blocks) {
            block.loadTexture();
        }
        for (Pig pig : pigs) {
            pig.loadTexture();
        }
        catapult.loadTexture();
    }
    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        camera.position.set(camera.viewportWidth / 2, camera.viewportHeight / 2, 0);
    }
//    private void cleanupSaveFiles() {
//        try {
//            File gameStateFile = new File(filename + "/gameState.ser");
//            File pauseStateFile = new File(filename + "/pauseState.ser");
//
//            if (gameStateFile.exists()) {
//                gameStateFile.delete();
//            }
//            if (pauseStateFile.exists()) {
//                pauseStateFile.delete();
//            }
//        } catch (Exception e) {
//            System.err.println("Failed to cleanup save files: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }

    @Override
    public void dispose() {

        background.dispose();
        shapeRenderer.dispose();
        settingsButtonTexture.dispose();
        pauseButtonTexture.dispose();

        for (Bird bird : birds) {
            bird.dispose();
        }

        for (Block block : blocks) {
            block.dispose();
        }

        for (Pig pig : pigs) {
            pig.dispose();
        }
        catapult.dispose();
    }

    @Override public void show() {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
}
