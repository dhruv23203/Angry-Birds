package com.angrybirds;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.angrybirds.FrontPageScreen;
import com.badlogic.gdx.utils.viewport.Viewport;

public class MyAngryBirdGame extends Game {
    public SpriteBatch batch;
    private Music backgroundMusic;
    private boolean musicPlaying; // Added this variable

    @Override
    public void create() {
        batch = new SpriteBatch();
        musicPlaying = true; // Initialize as true since music starts playing

        // Load and setup background music
        try {
            backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("background.mp3"));
            backgroundMusic.setLooping(true);     // Music will loop continuously
            backgroundMusic.setVolume(0.5f);      // Set volume to 50%
            backgroundMusic.play();               // Start playing immediately
        } catch (Exception e) {
            System.err.println("Error loading music: " + e.getMessage());
            musicPlaying = false; // Set to false if music fails to load
        }

        setScreen(new FrontPageScreen(this));
    }

    @Override
    public void render() {
        super.render();
    }

    // Add methods to control music
    public void pauseMusic() {
        if (backgroundMusic != null && backgroundMusic.isPlaying()) {
            backgroundMusic.pause();
            musicPlaying = false;
        }
    }

    public void resumeMusic() {
        if (backgroundMusic != null) {
            backgroundMusic.play();
            musicPlaying = true;
        }
    }

    public void setMusicVolume(float volume) {
        if (backgroundMusic != null) {
            backgroundMusic.setVolume(Math.max(0, Math.min(1, volume)));
        }
    }

    @Override
    public void dispose() {
        if (backgroundMusic != null) {
            backgroundMusic.dispose();
        }
        batch.dispose();
    }

    public boolean isMusicPlaying() {
        return musicPlaying;
    }


}
