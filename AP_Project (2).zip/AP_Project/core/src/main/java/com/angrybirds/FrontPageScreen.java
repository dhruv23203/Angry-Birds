package com.angrybirds;

import com.angrybirds.MyAngryBirdGame;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;

public class FrontPageScreen implements Screen {
    private final MyAngryBirdGame game;
    private OrthographicCamera camera;
    private Viewport viewport;

    private Texture backgroundImage, loadingSlide;
    private float progress;
    private float elapsedTime;
    private BitmapFont font;
    private GlyphLayout layout;

    // World dimensions
    private final float WORLD_WIDTH = 925f;
    private final float WORLD_HEIGHT = 480f;

    // Loading bar dimensions and position
    private final float BAR_WIDTH = 300f;
    private final float BAR_HEIGHT = 30f;
    private final float BAR_X = (WORLD_WIDTH - BAR_WIDTH) / 2;
    private final float BAR_Y = 10f;
    private final float TEXT_Y_OFFSET = 50f; // Distance above loading bar

    // Animation constants
    private final float LOADING_DURATION = 2f;

    public FrontPageScreen(MyAngryBirdGame game) {
        this.game = game;

        // Initialize camera and viewport
        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
        camera.position.set(WORLD_WIDTH / 2, WORLD_HEIGHT / 2, 0);
        viewport.apply();

        // Load textures
        backgroundImage = new Texture(Gdx.files.internal("background1.png"));
        loadingSlide = new Texture(Gdx.files.internal("loading_slide.png"));

        // Initialize font
        initializeFont();

        // Create layout for text centering
        layout = new GlyphLayout();
        layout.setText(font, "LOADING");

        // Initialize animation
        progress = 0f;
        elapsedTime = 0f;
    }

    private void initializeFont() {
        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(
            Gdx.files.internal("Oxanium-ExtraBold.ttf")); // Make sure you have this font
        FreeTypeFontGenerator.FreeTypeFontParameter parameter =
            new FreeTypeFontGenerator.FreeTypeFontParameter();

        parameter.size = 40; // Font size
        parameter.color = Color.WHITE;
        parameter.borderWidth = 3;
        parameter.borderColor = Color.BLACK;
        parameter.shadowOffsetX = 3;
        parameter.shadowOffsetY = 3;
        parameter.shadowColor = new Color(0, 0, 0, 0.75f);

        font = generator.generateFont(parameter);
        generator.dispose();
    }

    @Override
    public void render(float delta) {
        // Update animation
        elapsedTime += delta;
        progress = Math.min(1f, elapsedTime / LOADING_DURATION);

        // Clear screen
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Update camera
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        game.batch.begin();

        // Draw background
        game.batch.draw(backgroundImage, 0, 0, WORLD_WIDTH, WORLD_HEIGHT);

        // Draw "LOADING" text
        font.draw(game.batch, "LOADING",
            BAR_X + (BAR_WIDTH - layout.width) / 2,  // Center text above bar
            BAR_Y + BAR_HEIGHT + TEXT_Y_OFFSET);

        // Draw loading bar background (darker rectangle)
        game.batch.setColor(0.3f, 0.3f, 0.3f, 1f);
        game.batch.draw(loadingSlide, BAR_X, BAR_Y, BAR_WIDTH, BAR_HEIGHT);

        // Draw loading progress (yellow rectangle)
        game.batch.setColor(1f, 1f, 0f, 1f);
        game.batch.draw(loadingSlide, BAR_X, BAR_Y, BAR_WIDTH * progress, BAR_HEIGHT);

        // Reset color
        game.batch.setColor(1, 1, 1, 1);

        game.batch.end();

        // Check for transition to main menu
        if (elapsedTime >= LOADING_DURATION) {
            dispose();
            game.setScreen(new MainMenuScreen(game));
        }
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    @Override
    public void dispose() {
        if (backgroundImage != null) backgroundImage.dispose();
        if (loadingSlide != null) loadingSlide.dispose();
        if (font != null) font.dispose();
    }

    // Required screen interface methods
    @Override public void show() {}
    @Override public void pause() {}
    @Override public void resume() {}
    @Override public void hide() {}
}
