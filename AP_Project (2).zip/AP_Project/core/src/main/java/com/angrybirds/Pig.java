package com.angrybirds;

import java.util.List;

import static com.angrybirds.Bird.GRAVITY;

public abstract class Pig extends GameObject {
    protected float health;
    protected float currentHealth;
    protected float velocityY;
    protected boolean isDead;

    public Pig(float x, float y, float size, float health) {
        super(x, y, size, size);
        this.health = health;
        this.currentHealth = health;
        this.velocityY = 0;
        this.isDead = false;
    }

    public void takeDamage(float damage) {
        currentHealth -= damage;
        if (currentHealth <= 0) {
            isDead = true;
        }
    }

    public boolean isDead() {
        return isDead;
    }

    public float getVelocityY() {
        return velocityY;
    }

    public void setVelocityY(float velocityY) {
        this.velocityY = velocityY;
    }

    public void updatePosition(float delta,List<Block> blocks, float VELOCITY_DAMAGE_THRESHOLD) {
        if (!isDead) {
            // Apply gravity and update position
            velocityY += GRAVITY * delta;
            setY(getY() + velocityY * delta);

            // Check for collision with ground or blocks
            checkCollisions(blocks, VELOCITY_DAMAGE_THRESHOLD);
        }
    }

    private void checkCollisions(List<Block> blocks, float VELOCITY_DAMAGE_THRESHOLD) {
        // Check for collision with ground
        if (getY() <= 70f) {
            setY(70f);
            velocityY = 0;
        } else {
            // Check for collision with blocks below
            for (Block block : blocks) {
                if (!block.isDestroyed() && checkCollision(block)) {
                    setY(block.getY() + block.getHeight());
                    velocityY = 0;
                    break;
                }
            }
        }

        // If pig has fallen too fast, take damage
        if (Math.abs(velocityY) > VELOCITY_DAMAGE_THRESHOLD) {
            takeDamage(1);
        }
    }

    private boolean checkCollision(Block block) {
        return getX() < block.getX() + block.getWidth() && getX() + getWidth() > block.getX() &&
            getY() < block.getY() + block.getHeight() && getY() + getHeight() > block.getY();
    }

    public float getHealth() {
        return currentHealth;
    }

    public abstract void dispose();

    public void setHealth(int health) {  // Updated setter implementation
        this.health = health;
        if (this.health <= 0) {
            this.isDead = true;
            this.health = 0;
        } else {
            this.isDead = false;
        }
    }
}
